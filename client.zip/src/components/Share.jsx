import React from 'react'

const Share = () => {
    return (
        <button className='btn btn-outline-success'>Share Favorites!</button>
    )
}

export default Share